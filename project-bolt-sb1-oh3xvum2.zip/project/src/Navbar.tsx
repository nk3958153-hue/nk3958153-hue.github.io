import { useEffect, useState } from "react";
import { Menu, X, Download } from "lucide-react";
import { useScrollSpy } from "./hooks";
import { portfolio } from "./data";

const NAV_ITEMS = [
  { label: "Home", id: "home" },
  { label: "About", id: "about" },
  { label: "Education", id: "education" },
  { label: "Skills", id: "skills" },
  { label: "Projects", id: "projects" },
  { label: "Experience", id: "experience" },
  { label: "Certifications", id: "certifications" },
  { label: "Interests", id: "interests" },
  { label: "Contact", id: "contact" },
];

export function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const active = useScrollSpy(NAV_ITEMS.map((n) => n.id));

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 60);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const handleClick = (id: string) => {
    setMenuOpen(false);
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <>
      <nav
        className="fixed top-0 left-0 right-0 z-[9500] transition-all duration-500"
        style={{
          background: scrolled ? "rgba(10, 14, 26, 0.8)" : "transparent",
          backdropFilter: scrolled ? "blur(12px)" : "none",
          WebkitBackdropFilter: scrolled ? "blur(12px)" : "none",
          borderBottom: scrolled ? "1px solid rgba(0, 217, 255, 0.1)" : "1px solid transparent",
        }}
      >
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <button
            onClick={() => handleClick("home")}
            className="flex items-center gap-2 font-bold text-lg tracking-tight"
            style={{ cursor: "none" }}
          >
            <span className="gradient-text">indexs</span>
          </button>

          <div className="hidden lg:flex items-center gap-6">
            {NAV_ITEMS.map((item) => (
              <button
                key={item.id}
                className={`nav-link ${active === item.id ? "active" : ""}`}
                onClick={() => handleClick(item.id)}
              >
                {item.label}
              </button>
            ))}
            <a
              href={portfolio.resumeUrl}
              download
              className="btn-primary"
              style={{ padding: "0.5rem 1.2rem", fontSize: "0.8rem" }}
            >
              <Download size={14} />
              Resume
            </a>
          </div>

          <button
            className="lg:hidden text-slate-300"
            onClick={() => setMenuOpen(true)}
            aria-label="Open menu"
          >
            <Menu size={24} />
          </button>
        </div>
      </nav>

      <div className={`mobile-menu ${menuOpen ? "open" : ""}`}>
        <button
          className="absolute top-6 right-6 text-slate-300"
          onClick={() => setMenuOpen(false)}
          aria-label="Close menu"
        >
          <X size={28} />
        </button>
        {NAV_ITEMS.map((item, i) => (
          <button
            key={item.id}
            onClick={() => handleClick(item.id)}
            className="text-xl font-medium text-slate-300 hover:text-cyan-300 transition-colors"
            style={{
              opacity: menuOpen ? 1 : 0,
              transform: menuOpen ? "translateY(0)" : "translateY(20px)",
              transition: `opacity 0.3s ${i * 0.05}s, transform 0.3s ${i * 0.05}s`,
            }}
          >
            {item.label}
          </button>
        ))}
        <a
          href={portfolio.resumeUrl}
          download
          className="btn-primary mt-4"
          onClick={() => setMenuOpen(false)}
        >
          <Download size={16} />
          Download Resume
        </a>
      </div>
    </>
  );
}
