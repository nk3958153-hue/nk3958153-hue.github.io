import { useEffect, useRef } from "react";

const LABELS = [
  { text: "Python", angle: 0, orbit: 1 },
  { text: "Machine Learning", angle: 72, orbit: 2 },
  { text: "Data Science", angle: 144, orbit: 1 },
  { text: "AI", angle: 216, orbit: 3 },
  { text: "NumPy", angle: 288, orbit: 2 },
];

export function AIVisual() {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    if (window.innerWidth < 768) return;

    const handleMove = (e: MouseEvent) => {
      const rect = el.getBoundingClientRect();
      const x = (e.clientX - rect.left - rect.width / 2) / rect.width;
      const y = (e.clientY - rect.top - rect.height / 2) / rect.height;
      el.style.transform = `translate(${x * 20}px, ${y * 20}px)`;
    };
    const handleLeave = () => {
      el.style.transform = "translate(0, 0)";
    };

    window.addEventListener("mousemove", handleMove);
    el.addEventListener("mouseleave", handleLeave);
    return () => {
      window.removeEventListener("mousemove", handleMove);
      el.removeEventListener("mouseleave", handleLeave);
    };
  }, []);

  const orbitSizes = { 1: 150, 2: 210, 3: 280 };

  return (
    <div
      ref={containerRef}
      className="ai-core"
      style={{
        width: 320,
        height: 320,
        transition: "transform 0.3s ease-out",
      }}
    >
      {/* Orbital rings */}
      <div className="ai-orbit o1" />
      <div className="ai-orbit o2" />
      <div className="ai-orbit o3" />

      {/* Central core */}
      <div className="ai-core-center" />

      {/* Orbiting dots */}
      <div
        className="ai-orbit-dot"
        style={{
          top: "50%",
          left: "50%",
          transform: "rotate(0deg) translateX(75px) rotate(0deg)",
          transformOrigin: "center",
        }}
      />
      <div
        className="ai-orbit-dot"
        style={{
          top: "50%",
          left: "50%",
          width: "6px",
          height: "6px",
          background: "#7c3aed",
          boxShadow: "0 0 10px rgba(124,58,237,0.8)",
          transform: "rotate(120deg) translateX(105px)",
        }}
      />
      <div
        className="ai-orbit-dot"
        style={{
          top: "50%",
          left: "50%",
          width: "5px",
          height: "5px",
          background: "#0099ff",
          boxShadow: "0 0 10px rgba(0,153,255,0.8)",
          transform: "rotate(240deg) translateX(140px)",
        }}
      />

      {/* Floating labels */}
      {LABELS.map((label, i) => {
        const radius = orbitSizes[label.orbit as 1 | 2 | 3] / 2 + 15;
        const rad = (label.angle * Math.PI) / 180;
        const x = Math.cos(rad) * radius;
        const y = Math.sin(rad) * radius;
        return (
          <div
            key={i}
            className="ai-label"
            style={{
              top: "50%",
              left: "50%",
              transform: `translate(calc(-50% + ${x}px), calc(-50% + ${y}px))`,
              opacity: 0.7,
              animation: `node-float ${3 + i * 0.5}s ease-in-out infinite`,
              animationDelay: `${i * 0.3}s`,
            }}
          >
            {label.text}
          </div>
        );
      })}
    </div>
  );
}
