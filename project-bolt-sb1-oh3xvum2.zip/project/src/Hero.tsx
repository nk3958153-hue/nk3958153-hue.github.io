import { ArrowDown, Github, Linkedin, Download, Sparkles } from "lucide-react";
import { portfolio } from "./data";
import { useTypingEffect } from "./hooks";
import { AIVisual } from "./AIVisual";

export function Hero() {
  const typedText = useTypingEffect(portfolio.taglines);

  return (
    <section
      id="home"
      className="relative min-h-screen flex items-center justify-center px-6 pt-16"
    >
      <div className="max-w-7xl mx-auto grid lg:grid-cols-2 gap-12 items-center w-full">
        {/* Left: text */}
        <div className="text-center lg:text-left z-10">
          <div className="hero-entrance d1 inline-flex items-center gap-2 px-4 py-1.5 rounded-full glass mb-6">
            <Sparkles size={14} className="text-cyan-300" />
            <span className="text-xs font-medium text-slate-300 tracking-wide">
              AI & ML Student Portfolio
            </span>
          </div>

          <h1 className="hero-entrance d2 text-4xl sm:text-5xl lg:text-6xl font-bold leading-tight glow-text">
            <span className="gradient-text">{portfolio.name}</span>
          </h1>

          <p className="hero-entrance d2 text-base sm:text-lg text-slate-400 mt-3 font-medium">
            {portfolio.role}
          </p>

          <div className="hero-entrance d3 h-7 mt-4 flex items-center justify-center lg:justify-start">
            <span className="text-cyan-300 font-semibold text-base sm:text-lg">
              {typedText}
            </span>
            <span className="typing-cursor h-5" />
          </div>

          <div className="hero-entrance d4 flex flex-wrap gap-3 mt-8 justify-center lg:justify-start">
            <a
              href="#projects"
              onClick={(e) => {
                e.preventDefault();
                document.getElementById("projects")?.scrollIntoView({ behavior: "smooth" });
              }}
              className="btn-primary"
            >
              Explore My Work
              <ArrowDown size={16} />
            </a>
            <a
              href={portfolio.contact.github}
              target="_blank"
              rel="noopener noreferrer"
              className="btn-ghost"
            >
              <Github size={16} />
              GitHub
            </a>
            <a
              href={portfolio.contact.linkedin}
              target="_blank"
              rel="noopener noreferrer"
              className="btn-ghost"
            >
              <Linkedin size={16} />
              LinkedIn
            </a>
            <a href={portfolio.resumeUrl} download className="btn-ghost">
              <Download size={16} />
              Download Resume
            </a>
          </div>
        </div>

        {/* Right: AI visual */}
        <div className="hero-entrance d3 flex items-center justify-center relative">
          <AIVisual />
        </div>
      </div>

      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 hero-entrance d4">
        <button
          onClick={() => document.getElementById("about")?.scrollIntoView({ behavior: "smooth" })}
          className="text-slate-500 hover:text-cyan-300 transition-colors"
          aria-label="Scroll down"
          style={{ cursor: "none" }}
        >
          <ArrowDown size={24} className="animate-bounce" />
        </button>
      </div>
    </section>
  );
}
