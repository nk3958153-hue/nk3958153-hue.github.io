export const portfolio = {
  name: "NIRMAL KUMAR S",
  role: "Artificial Intelligence & Machine Learning Student",
  location: "Chennai, Tamil Nadu, India",
  taglines: [
    "AI & ML Enthusiast",
    "Python Learner",
    "Data Science Explorer",
    "Future AI Engineer",
  ],
  about:
    "I am an Artificial Intelligence and Machine Learning student interested in Artificial Intelligence, Machine Learning, Data Science, and Software Development. I am building my technical skills through academic learning, projects, coding practice, and practical experience. I am particularly interested in Python, Machine Learning, Data Analysis, and developing useful technology-based solutions. I am continuously learning and improving my programming, problem-solving, and development skills.",
  education: {
    college: "RMD Engineering College",
    branch: "Artificial Intelligence & Machine Learning (AIML)",
    location: "Chennai, Tamil Nadu, India",
    cgpa: "CGPA — To be updated",
  },
  skills: [
    {
      category: "Programming",
      icon: "Code2",
      items: ["Python", "C", "C++"],
    },
    {
      category: "AI & Machine Learning",
      icon: "BrainCircuit",
      items: [
        "Machine Learning Fundamentals",
        "Data Analysis",
        "NumPy",
        "Pandas",
        "Scikit-learn",
      ],
    },
    {
      category: "Data Analysis",
      icon: "BarChart3",
      items: ["Data Analysis", "NumPy", "Pandas", "Data Preprocessing"],
    },
    {
      category: "Web Development",
      icon: "Globe",
      items: ["HTML", "CSS"],
    },
    {
      category: "Tools & Platforms",
      icon: "Wrench",
      items: ["Git", "GitHub", "Jupyter Notebook"],
    },
    {
      category: "Computer Science",
      icon: "Cpu",
      items: ["Data Structures", "Object-Oriented Programming", "Problem Solving"],
    },
  ],
  projects: [
    {
      title: "Real-Time Disaster Alert System",
      description:
        "A technology-based project designed to provide real-time disaster-related alerts using live weather and earthquake data. The system focuses on collecting information through APIs, analyzing possible threats, providing alerts, and visualizing locations.",
      technologies: [
        "JavaScript",
        "APIs",
        "Firebase",
        "Google Maps API",
        "Weather Data",
        "Earthquake Data",
        "Threat Analysis",
        "Location Visualization",
        "Real-time Alerts",
      ],
      github: "https://github.com/nk3958153-hue",
      demo: null as string | null,
      type: "disaster",
    },
    {
      title: "Machine Learning Project",
      description:
        "A Machine Learning project involving dataset preparation, data analysis, preprocessing, model development, experimentation, and an end-to-end Machine Learning workflow using Python-based tools.",
      technologies: [
        "Python",
        "Machine Learning",
        "Data Preprocessing",
        "Data Analysis",
        "Model Development",
        "Model Experimentation",
        "NumPy",
        "Pandas",
        "Scikit-learn",
        "Jupyter Notebook",
      ],
      github: "https://github.com/nk3958153-hue/PRODIG_ML_5",
      demo: null as string | null,
      type: "ml",
    },
  ],
  internships: [
    {
      role: "Full Stack Web Development Intern",
      organization: "Skill Nexis",
      program: "6 Weeks Online Internship",
      domain: "Full Stack Web Development (MERN)",
      date: "October 2026",
      description:
        "Successfully completed a 6-week online internship program in Full Stack Web Development (MERN) at Skill Nexis.",
    },
  ],
  certifications: [
    {
      title: "GenAI Powered Data Analytics",
      type: "Job Simulation",
      platform: "Forage",
      date: "September 17, 2026",
      tasks: [
        "Exploratory data analysis",
        "Risk profiling",
        "Predicting delinquency using AI",
        "Business reporting",
        "Data storytelling for collections strategy",
        "Implementing an AI-driven collections strategy",
      ],
    },
  ],
  languages: ["English", "German"],
  interests: [
    "Artificial Intelligence",
    "Machine Learning",
    "Data Science",
    "Software Development",
  ],
  contact: {
    phone: "8072099938",
    collegeEmail: "25al070@rmd.ac.in",
    personalEmail: "nk3958153@gmail.com",
    github: "https://github.com/nk3958153-hue",
    linkedin: "https://www.linkedin.com/in/nirmal-kumar-a35344439/",
  },
  resumeUrl: "/resume.pdf",
};

export type Portfolio = typeof portfolio;
