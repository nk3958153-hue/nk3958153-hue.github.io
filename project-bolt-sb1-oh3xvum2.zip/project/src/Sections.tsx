import {
  Code2, BrainCircuit, BarChart3, Globe, Wrench, Cpu,
  Github, ExternalLink, MapPin, Mail, Phone, Linkedin,
  GraduationCap, Briefcase, Award, Heart, Download, Sparkles,
  type LucideIcon,
} from "lucide-react";
import { portfolio } from "./data";
import { Reveal, useScrollReveal, useTilt } from "./hooks";

function SectionHeading({ title, subtitle }: { title: string; subtitle?: string }) {
  const { ref, visible } = useScrollReveal<HTMLDivElement>();
  return (
    <div ref={ref} className="text-center mb-14">
      <h2 className={`section-accent ${visible ? "visible" : ""} text-3xl sm:text-4xl font-bold`}>
        <span className="gradient-text">{title}</span>
      </h2>
      {subtitle && (
        <p className="text-slate-400 mt-4 text-sm sm:text-base max-w-2xl mx-auto">{subtitle}</p>
      )}
    </div>
  );
}

/* ===== About ===== */
export function About() {
  return (
    <section id="about" className="relative z-10 py-24 px-6">
      <div className="max-w-4xl mx-auto">
        <SectionHeading title="About Me" />
        <Reveal variant="up">
          <div className="glass rounded-2xl p-8 sm:p-10">
            <p className="text-slate-300 leading-relaxed text-base sm:text-lg" style={{ lineHeight: 1.75 }}>
              {portfolio.about}
            </p>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

/* ===== Education ===== */
export function Education() {
  const tiltRef = useTilt<HTMLDivElement>(5);
  return (
    <section id="education" className="relative z-10 py-24 px-6">
      <div className="max-w-4xl mx-auto">
        <SectionHeading title="Education" />
        <Reveal variant="scale">
          <div ref={tiltRef} className="tilt-card card p-8 sm:p-10">
            <div className="flex items-start gap-4">
              <div className="flex-shrink-0 w-14 h-14 rounded-xl bg-gradient-to-br from-cyan-500/20 to-blue-500/20 flex items-center justify-center border border-cyan-500/20">
                <GraduationCap className="text-cyan-300" size={26} />
              </div>
              <div className="flex-1">
                <h3 className="text-xl font-bold text-slate-100">{portfolio.education.college}</h3>
                <p className="text-cyan-300 font-medium mt-1 text-sm">
                  {portfolio.education.branch}
                </p>
                <p className="text-slate-400 text-sm mt-2 flex items-center gap-1.5">
                  <MapPin size={14} />
                  {portfolio.education.location}
                </p>
                <div className="mt-4 inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-800/50 border border-slate-700/50">
                  <span className="text-xs text-slate-400">{portfolio.education.cgpa}</span>
                </div>
              </div>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

/* ===== Skills ===== */
const ICON_MAP: Record<string, LucideIcon> = {
  Code2, BrainCircuit, BarChart3, Globe, Wrench, Cpu,
};

export function Skills() {
  const { ref, visible } = useScrollReveal<HTMLDivElement>({ threshold: 0.1 });
  return (
    <section id="skills" className="relative z-10 py-24 px-6">
      <div className="max-w-6xl mx-auto">
        <SectionHeading title="Skills" subtitle="Technical skills I've been building through academic learning and hands-on practice." />
        <div ref={ref} className={`grid sm:grid-cols-2 lg:grid-cols-3 gap-5 stagger ${visible ? "visible" : ""}`}>
          {portfolio.skills.map((skill, i) => {
            const Icon = ICON_MAP[skill.icon] || Code2;
            return (
              <div
                key={i}
                className="skill-card card p-6"
                onMouseMove={(e) => {
                  const rect = e.currentTarget.getBoundingClientRect();
                  e.currentTarget.style.setProperty("--mx", `${e.clientX - rect.left}px`);
                  e.currentTarget.style.setProperty("--my", `${e.clientY - rect.top}px`);
                }}
              >
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-cyan-500/15 to-blue-500/15 flex items-center justify-center border border-cyan-500/15">
                    <Icon size={18} className="text-cyan-300" />
                  </div>
                  <h3 className="font-bold text-slate-100 text-sm">{skill.category}</h3>
                </div>
                <div className="flex flex-wrap gap-2">
                  {skill.items.map((item, j) => (
                    <span key={j} className="tag">{item}</span>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

/* ===== Project Visuals ===== */
function DisasterVisual() {
  return (
    <div className="relative h-40 rounded-lg overflow-hidden bg-slate-900/50 border border-slate-700/30 mb-4">
      {/* Grid lines */}
      <div
        className="absolute inset-0"
        style={{
          backgroundImage:
            "linear-gradient(rgba(0,217,255,0.08) 1px,transparent 1px),linear-gradient(90deg,rgba(0,217,255,0.08) 1px,transparent 1px)",
          backgroundSize: "30px 30px",
        }}
      />
      {/* Radar pulses */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
        <div className="radar-pulse" style={{ animationDelay: "0s" }} />
        <div className="radar-pulse" style={{ animationDelay: "1s" }} />
        <div className="radar-pulse" style={{ animationDelay: "2s" }} />
      </div>
      {/* Map markers */}
      <div className="map-marker" style={{ top: "25%", left: "20%" }} />
      <div className="map-marker" style={{ top: "60%", left: "70%", animationDelay: "0.5s" }} />
      <div className="map-marker" style={{ top: "40%", left: "50%", animationDelay: "1s" }} />
      <div className="map-marker" style={{ top: "70%", left: "30%", animationDelay: "1.5s" }} />
    </div>
  );
}

function MLVisual() {
  const nodes = [
    { top: "20%", left: "15%" },
    { top: "35%", left: "50%" },
    { top: "60%", left: "25%" },
    { top: "25%", left: "75%" },
    { top: "70%", left: "65%" },
    { top: "50%", left: "85%" },
    { top: "80%", left: "45%" },
  ];
  return (
    <div className="relative h-40 rounded-lg overflow-hidden bg-slate-900/50 border border-slate-700/30 mb-4">
      <svg className="absolute inset-0 w-full h-full" style={{ opacity: 0.3 }}>
        <line x1="15%" y1="20%" x2="50%" y2="35%" stroke="#00d9ff" strokeWidth="0.5" />
        <line x1="50%" y1="35%" x2="25%" y2="60%" stroke="#00d9ff" strokeWidth="0.5" />
        <line x1="50%" y1="35%" x2="75%" y2="25%" stroke="#00d9ff" strokeWidth="0.5" />
        <line x1="25%" y1="60%" x2="65%" y2="70%" stroke="#00d9ff" strokeWidth="0.5" />
        <line x1="75%" y1="25%" x2="85%" y2="50%" stroke="#00d9ff" strokeWidth="0.5" />
        <line x1="65%" y1="70%" x2="45%" y2="80%" stroke="#00d9ff" strokeWidth="0.5" />
        <line x1="85%" y1="50%" x2="65%" y2="70%" stroke="#00d9ff" strokeWidth="0.5" />
      </svg>
      {nodes.map((n, i) => (
        <div
          key={i}
          className="ml-node"
          style={{ top: n.top, left: n.left, animationDelay: `${i * 0.4}s` }}
        />
      ))}
    </div>
  );
}

/* ===== Projects ===== */
export function Projects() {
  return (
    <section id="projects" className="relative z-10 py-24 px-6">
      <div className="max-w-6xl mx-auto">
        <SectionHeading title="Projects" subtitle="Hands-on projects exploring real-world problems with technology." />
        <div className="grid lg:grid-cols-2 gap-6">
          {portfolio.projects.map((project, i) => {
            const tiltRef = useTilt<HTMLDivElement>(6);
            return (
              <Reveal key={i} variant={i === 0 ? "left" : "right"}>
                <div ref={tiltRef} className="tilt-card card p-6 h-full">
                  {project.type === "disaster" ? <DisasterVisual /> : <MLVisual />}
                  <h3 className="text-lg font-bold text-slate-100 mb-2">{project.title}</h3>
                  <p className="text-slate-400 text-sm leading-relaxed mb-4">{project.description}</p>
                  <div className="flex flex-wrap gap-2 mb-5">
                    {project.technologies.map((tech, j) => (
                      <span key={j} className="tag">{tech}</span>
                    ))}
                  </div>
                  <div className="flex gap-3">
                    {project.github && (
                      <a
                        href={project.github}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="btn-ghost"
                        style={{ padding: "0.5rem 1.2rem", fontSize: "0.8rem" }}
                      >
                        <Github size={14} />
                        GitHub
                      </a>
                    )}
                    {project.demo && (
                      <a
                        href={project.demo}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="btn-primary"
                        style={{ padding: "0.5rem 1.2rem", fontSize: "0.8rem" }}
                      >
                        <ExternalLink size={14} />
                        Live Demo
                      </a>
                    )}
                  </div>
                </div>
              </Reveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}

/* ===== Experience (Timeline) ===== */
export function Experience() {
  const { ref: lineRef, visible: lineVisible } = useScrollReveal<HTMLDivElement>({ threshold: 0.3 });
  return (
    <section id="experience" className="relative z-10 py-24 px-6">
      <div className="max-w-4xl mx-auto">
        <SectionHeading title="Internship & Experience" />
        <div ref={lineRef} className="relative pl-12">
          <div className={`timeline-line ${lineVisible ? "visible" : ""}`} />
          {portfolio.internships.map((intern, i) => (
            <Reveal key={i} variant="left" delay={200}>
              <div className="relative mb-8">
                <div className="timeline-dot" style={{ top: 8 }} />
                <div className="card p-6">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-cyan-500/15 to-blue-500/15 flex items-center justify-center border border-cyan-500/15">
                      <Briefcase size={18} className="text-cyan-300" />
                    </div>
                    <div>
                      <h3 className="font-bold text-slate-100 text-sm">{intern.role}</h3>
                      <p className="text-cyan-300 text-xs font-medium">{intern.organization}</p>
                    </div>
                  </div>
                  <div className="space-y-1 text-xs text-slate-400 mb-3">
                    <p><span className="text-slate-500">Program:</span> {intern.program}</p>
                    <p><span className="text-slate-500">Domain:</span> {intern.domain}</p>
                    <p><span className="text-slate-500">Date:</span> {intern.date}</p>
                  </div>
                  <p className="text-slate-400 text-sm leading-relaxed">{intern.description}</p>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ===== Certifications ===== */
export function Certifications() {
  const { ref, visible } = useScrollReveal<HTMLDivElement>({ threshold: 0.1 });
  return (
    <section id="certifications" className="relative z-10 py-24 px-6">
      <div className="max-w-4xl mx-auto">
        <SectionHeading title="Certifications & Job Simulations" />
        <div ref={ref} className={`stagger ${visible ? "visible" : ""}`}>
          {portfolio.certifications.map((cert, i) => (
            <div key={i} className="cert-card card p-8">
              <div className="flex items-start gap-4">
                <div className="flex-shrink-0 w-14 h-14 rounded-xl bg-gradient-to-br from-amber-500/15 to-orange-500/15 flex items-center justify-center border border-amber-500/20">
                  <Award size={24} className="text-amber-300" />
                </div>
                <div className="flex-1">
                  <div className="flex flex-wrap items-center gap-2 mb-1">
                    <h3 className="text-lg font-bold text-slate-100">{cert.title}</h3>
                    <span className="px-2.5 py-0.5 rounded-full text-[0.65rem] font-bold uppercase tracking-wide bg-amber-500/10 text-amber-300 border border-amber-500/20">
                      {cert.type}
                    </span>
                  </div>
                  <p className="text-slate-400 text-sm">
                    {cert.platform} &middot; {cert.date}
                  </p>
                  <ul className="mt-4 space-y-1.5">
                    {cert.tasks.map((task, j) => (
                      <li key={j} className="text-slate-400 text-sm flex items-start gap-2">
                        <span className="text-cyan-400 mt-0.5">▸</span>
                        {task}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ===== Interests ===== */
export function Interests() {
  const { ref, visible } = useScrollReveal<HTMLDivElement>({ threshold: 0.1 });
  return (
    <section id="interests" className="relative z-10 py-24 px-6">
      <div className="max-w-4xl mx-auto">
        <SectionHeading title="Areas of Interest" />
        <div ref={ref} className={`flex flex-wrap justify-center gap-4 stagger ${visible ? "visible" : ""}`}>
          {portfolio.interests.map((interest, i) => (
            <div
              key={i}
              className="card px-6 py-4 flex items-center gap-3"
            >
              <Heart size={18} className="text-cyan-300" />
              <span className="font-medium text-slate-200 text-sm">{interest}</span>
            </div>
          ))}
        </div>
        <div className="text-center mt-10">
          <p className="text-slate-500 text-xs uppercase tracking-widest mb-3">Languages</p>
          <div className="flex justify-center gap-3">
            {portfolio.languages.map((lang, i) => (
              <span key={i} className="tag">{lang}</span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

/* ===== Resume ===== */
export function Resume() {
  return (
    <section id="resume" className="relative z-10 py-24 px-6">
      <div className="max-w-4xl mx-auto">
        <SectionHeading title="Resume" />
        <Reveal variant="scale">
          <div className="glass rounded-2xl p-10 sm:p-14 text-center">
            <div className="inline-flex w-16 h-16 rounded-2xl bg-gradient-to-br from-cyan-500/20 to-blue-500/20 items-center justify-center border border-cyan-500/20 mb-6">
              <Download size={28} className="text-cyan-300" />
            </div>
            <h3 className="text-xl font-bold text-slate-100 mb-2">Download My Resume</h3>
            <p className="text-slate-400 text-sm mb-6 max-w-md mx-auto">
              Get a complete overview of my education, skills, projects, and experience in a single PDF.
            </p>
            <a href={portfolio.resumeUrl} download className="btn-primary">
              <Download size={16} />
              Download Resume
            </a>
            <p className="text-slate-600 text-xs mt-4">
              Placeholder file — replace <code className="text-slate-500">public/resume.pdf</code> with your actual resume.
            </p>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

/* ===== Contact ===== */
const CONTACT_CARDS = [
  { icon: Phone, label: "Phone", value: portfolio.contact.phone, href: `tel:${portfolio.contact.phone}` },
  { icon: Mail, label: "College Email", value: portfolio.contact.collegeEmail, href: `mailto:${portfolio.contact.collegeEmail}` },
  { icon: Mail, label: "Personal Email", value: portfolio.contact.personalEmail, href: `mailto:${portfolio.contact.personalEmail}` },
  { icon: Github, label: "GitHub", value: "nk3958153-hue", href: portfolio.contact.github },
  { icon: Linkedin, label: "LinkedIn", value: "nirmal-kumar", href: portfolio.contact.linkedin },
  { icon: MapPin, label: "Location", value: portfolio.location, href: null as string | null },
];

export function Contact() {
  const { ref, visible } = useScrollReveal<HTMLDivElement>({ threshold: 0.1 });
  return (
    <section id="contact" className="relative z-10 py-24 px-6">
      <div className="max-w-4xl mx-auto">
        <SectionHeading title="Contact" subtitle="Let's connect — feel free to reach out for opportunities, collaborations, or just a chat." />
        <div ref={ref} className={`grid sm:grid-cols-2 gap-4 stagger ${visible ? "visible" : ""}`}>
          {CONTACT_CARDS.map((card, i) => {
            const Icon = card.icon;
            const content = (
              <div className="card p-5 flex items-center gap-4 group">
                <div className="w-11 h-11 rounded-lg bg-gradient-to-br from-cyan-500/15 to-blue-500/15 flex items-center justify-center border border-cyan-500/15 transition-transform group-hover:scale-110">
                  <Icon size={18} className="text-cyan-300 transition-transform group-hover:scale-110" />
                </div>
                <div className="min-w-0">
                  <p className="text-xs text-slate-500 uppercase tracking-wide">{card.label}</p>
                  <p className="text-sm text-slate-200 font-medium truncate">{card.value}</p>
                </div>
              </div>
            );
            return card.href ? (
              <a key={i} href={card.href} target="_blank" rel="noopener noreferrer" className="block">
                {content}
              </a>
            ) : (
              <div key={i}>{content}</div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

/* ===== Footer ===== */
export function Footer() {
  return (
    <footer className="relative z-10 py-10 px-6 border-t border-slate-800/50">
      <div className="max-w-7xl mx-auto text-center">
        <div className="flex items-center justify-center gap-2 mb-3">
          <Sparkles size={16} className="text-cyan-300" />
          <span className="gradient-text font-bold text-lg">indexs</span>
        </div>
        <p className="text-slate-500 text-sm">
          {portfolio.name} &middot; {portfolio.role}
        </p>
        <p className="text-slate-600 text-xs mt-2">
          Built with React & Tailwind CSS &middot; {new Date().getFullYear()}
        </p>
      </div>
    </footer>
  );
}
