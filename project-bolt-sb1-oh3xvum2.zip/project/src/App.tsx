import { useState } from "react";
import { ParticleBackground, CursorGlow, Loader } from "./Background";
import { Navbar } from "./Navbar";
import { Hero } from "./Hero";
import {
  About, Education, Skills, Projects, Experience,
  Certifications, Interests, Resume, Contact, Footer,
} from "./Sections";

function App() {
  const [loading, setLoading] = useState(true);

  return (
    <>
      {loading && <Loader onDone={() => setLoading(false)} />}

      {/* Background layers */}
      <div className="bg-blob b1" />
      <div className="bg-blob b2" />
      <div className="bg-blob b3" />
      <div className="grid-overlay" />
      <ParticleBackground />
      <CursorGlow />

      {/* Content */}
      <Navbar />
      <main className="relative z-10">
        <Hero />
        <About />
        <Education />
        <Skills />
        <Projects />
        <Experience />
        <Certifications />
        <Interests />
        <Resume />
        <Contact />
      </main>
      <Footer />
    </>
  );
}

export default App;
